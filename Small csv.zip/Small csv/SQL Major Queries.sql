# Queries for Major prerequisites

select c.CourseName as missingMustCourses 
from courses c 
right join prerequisites p on p.CourseID = c.CourseID and Combination = 0 
and MajorID = "CSC05" 
where c.CourseName is not null and c.CourseName not in ("CSC1016S", "CSC2002S");

select c.CourseName as coursesNotEnrolledIn, p.Combination as combinationsNotEnrolledIn
from courses c 
right join prerequisites p on p.CourseID = c.CourseID and Combination <> 0 
and MajorID = "CSC05" 
where c.CourseName is not null and c.CourseName not in ("CSC1016S", "CSC2002S");

select c.CourseName as coursesEnrolledIn, p.Combination as combinationsEnrolledIn
from courses c 
right join prerequisites p on p.CourseID = c.CourseID and Combination <> 0 
and MajorID = "CSC05" 
where c.CourseName is not null and c.CourseName in ("MAM1008S", "CSC2002S");