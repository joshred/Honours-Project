# Queries for course & NQF counts

select count(CourseID) as s0y1 from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 0 and courses.Year = 1 ;
select count(CourseID) as s1y1 from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 1 and courses.Year = 1 ;
select count(CourseID) as s2y1 from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 2 and courses.Year = 1 ;
select count(CourseID) as s0y2 from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 0 and courses.Year = 2 ;
select count(CourseID) as s1y2 from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 1 and courses.Year = 2 ;
select count(CourseID) as s2y2 from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 2 and courses.Year = 2 ;
select count(CourseID) as s0y3 from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 0 and courses.Year = 3 ;
select count(CourseID) as s1y3 from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 1 and courses.Year = 3 ;
select count(CourseID) as s2y3 from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 2 and courses.Year = 3 ;

select count(CourseID) as halfCourses from courses where courseName in ("MAM1000W", "CSC1016S") and (Semester = 1 or Semester = 2) ;
select count(CourseID) as fullCourses from courses where courseName in ("MAM1000W", "CSC1016S") and (Semester = 0 ) ;
select count(CourseID) as sciHalfCourses from courses where courseName in ("MAM1000W", "CSC1016S") and Faculty = "SCI" and (Semester = 1 or Semester = 2) ;
select count(CourseID) as sciFullCourses from courses where courseName in ("MAM1000W", "CSC1016S") and Faculty = "SCI" and Semester = 0  ;
select count(CourseID) as seniorCourses from courses where courseName in ("MAM1000W", "CSC1016S") and (Semester = 1 or Semester = 2) ;
select count(CourseID) as seniorSciHalfCourses from courses where courseName in ("MAM1000W", "CSC1016S") and (Semester = 1 or Semester = 2) and Faculty = "SCI" and (courses.Year = 2 or courses.Year = 3) ;
select count(CourseID) as seniorSciFullCourses from courses where courseName in ("MAM1000W", "CSC1016S") and (Semester = 0) and Faculty = "SCI" and (courses.Year = 2 or courses.Year = 3) ;
select count(CourseID) as thirdSciHalfCourses from courses where courseName in ("MAM1000W", "CSC1016S") and (Semester = 1 or Semester = 2) and Faculty = "SCI" and (courses.Year = 3) ;
select count(CourseID) as thirdSciFullCourses from courses where courseName in ("MAM1000W", "CSC1016S") and (Semester = 0) and Faculty = "SCI" and (courses.Year = 3) ;
select count(CourseID) as seniorHalfCourses from courses where courseName in ("MAM1000W", "CSC1016S") and (Semester = 1 or Semester = 2) and (courses.Year = 2 or courses.Year = 3) ;
select count(CourseID) as seniorFullCourses from courses where courseName in ("MAM1000W", "CSC1016S") and (Semester = 0) and (courses.Year = 2 or courses.Year = 3) ;

#alter table majors add primary key(MajorID);
select coalesce(sum(Credits), 0) as totalNQF from courses where CourseName in ("MAM1000W", "CSC1016S") ;
select coalesce(sum(Credits), 0) as sciNQF from courses where CourseName in ("MAM1000W", "CSC1016S") and Faculty = "SCI";
select coalesce(sum(Credits), 0) as thirdNQF from courses where CourseName in ("MAM1000W", "CSC1016S") and courses.Year = 3 ;
select coalesce(sum(Credits), 0) as totalNQF from courses where CourseName in ("MAM1000W", "CSC1016S") ;

select coalesce(sum(Credits), 0) as s0y1NQF from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 0 and courses.Year = 1 ;
select coalesce(sum(Credits), 0) as s1y1NQF from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 1 and courses.Year = 1 ;
select coalesce(sum(Credits), 0) as s2y1NQF from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 2 and courses.Year = 1 ;
select coalesce(sum(Credits), 0) as s0y2NQF from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 0 and courses.Year = 2 ;
select coalesce(sum(Credits), 0) as s1y2NQF from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 1 and courses.Year = 2 ;
select coalesce(sum(Credits), 0) as s2y2NQF from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 2 and courses.Year = 2 ;
select coalesce(sum(Credits), 0) as s0y3NQF from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 0 and courses.Year = 3 ;
select coalesce(sum(Credits), 0) as s1y3NQF from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 1 and courses.Year = 3 ;
select coalesce(sum(Credits), 0) as s2y3NQF from courses where courseName in ("MAM1000W", "CSC1016S") and Semester = 2 and courses.Year = 3 ;

